

<div style="text-align: center; padding: 100px;">
    <h1 style="color: var(--text-color);font-size:65px;">Oh no... We lost this page</h1>
    <p style="color:var(--grey-text) ;font-size:14px;width:48%;margin:0 auto;">We searched everywhere but couldn’t find what you’re looking for. Let’s find
        a better place for you to go.</p>
    <a class="all-btn button-hover primary-btn " style="max-width: 160px; margin: 30px auto;"  href="{{ route('home') }}" >Back To Home</a>
</div>
<link rel="stylesheet" href="{{ asset('webui/css/app.css') }}">
<link rel="stylesheet" href="{{ asset('webui/css/listing.css') }}">
<div>
      <div class="title">
        <h2>Today’s Luxury Listings</h2>
        <p>Thousands of luxury home enthusiasts just like you visit our website.</p>
      </div>
</div>
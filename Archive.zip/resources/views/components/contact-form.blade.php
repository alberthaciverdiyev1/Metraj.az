 <div class="contact-form">
     <form action="">
         <h3>Contact Me</h3>
         <input type="text" placeholder="Your name" />
         <input type="email" placeholder="Email" />
         <input type="tel" placeholder="Phone" />
         <textarea placeholder="Message"></textarea>
         <div class="buttons">
             <button class="send-btn">
                 <i class="fa fa-envelope"></i> Send message
             </button>
             <button class="call-btn">
                 <i class="fa fa-phone"></i> Call
             </button>
         </div>
     </form>
 </div>
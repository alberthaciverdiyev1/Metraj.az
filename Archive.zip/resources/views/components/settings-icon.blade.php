<section id="settings-icon">
    <div class="container mx-auto px-4">
        <div class="settings-icon">
            <i class="bi bi-gear"></i>
        </div>
    </div>
</section>

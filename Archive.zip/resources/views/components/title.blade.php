<div class="title-section">
    <h2>{{ $title }}</h2>
    <p>{{ $subtitle }}</p>
</div>

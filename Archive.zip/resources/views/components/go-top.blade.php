<div class="gotop" id="scrollToTop">
    <svg class="progress-circle" width="45" height="45">
        <circle class="bg" cx="22.5" cy="22.5" r="18"></circle>
        <circle class="progress" cx="22.5" cy="22.5" r="18"></circle>
    </svg>
    <div class="up">
        <i class="bi bi-arrow-up-short"></i>
    </div>
</div>
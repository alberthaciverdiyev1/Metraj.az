<?php $__env->startSection('title', $agency['name']); ?>

<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
    ['label' => 'Home', 'url' => route('home')],
    ['label' => 'Agencies', 'url' => route('agencies')],
])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginaldfa1f9284bad1280f1688ddb5372b4e0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldfa1f9284bad1280f1688ddb5372b4e0 = $attributes; } ?>
<?php $component = App\View\Components\SettingsIcon::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('settings-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SettingsIcon::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldfa1f9284bad1280f1688ddb5372b4e0)): ?>
<?php $attributes = $__attributesOriginaldfa1f9284bad1280f1688ddb5372b4e0; ?>
<?php unset($__attributesOriginaldfa1f9284bad1280f1688ddb5372b4e0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldfa1f9284bad1280f1688ddb5372b4e0)): ?>
<?php $component = $__componentOriginaldfa1f9284bad1280f1688ddb5372b4e0; ?>
<?php unset($__componentOriginaldfa1f9284bad1280f1688ddb5372b4e0); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalb7adccc229b3a14ffb5f56d70b867112 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb7adccc229b3a14ffb5f56d70b867112 = $attributes; } ?>
<?php $component = App\View\Components\ScrollToTop::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('scroll-to-top'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ScrollToTop::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb7adccc229b3a14ffb5f56d70b867112)): ?>
<?php $attributes = $__attributesOriginalb7adccc229b3a14ffb5f56d70b867112; ?>
<?php unset($__attributesOriginalb7adccc229b3a14ffb5f56d70b867112); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb7adccc229b3a14ffb5f56d70b867112)): ?>
<?php $component = $__componentOriginalb7adccc229b3a14ffb5f56d70b867112; ?>
<?php unset($__componentOriginalb7adccc229b3a14ffb5f56d70b867112); ?>
<?php endif; ?>
<section id="side">
    <div class="container mx-auto px-4 ">
        <div class="side-agency">
            <section class="side-left">
                <div class="agencies-header">
                    <img src="<?php echo e($agency['image']); ?>" alt="">
                    <div class="agency-header-info">
                        <div class="logo">
                            <img src="<?php echo e($agency['logo']); ?>" alt="Logo">
                        </div>
                        <div class="">
                            <h2 class="text-2xl lg:text-4xl font-bold text-[color:var(--text-color)]">
                                <?php echo e($agency['name']); ?>

                            </h2>
                            <p class="text-gray-600">
                                <i class="bi bi-geo-alt"></i>
                                <?php echo e($agency['address']); ?>

                            </p>
                        </div>
                    </div>
                </div>
                <div class="agencies-info">
                    <h2>About <?php echo e($agency['name']); ?></h2>
                    <p><?php echo e($agency['description']); ?></p>
                    <h2 class="title">Location</h2>
                    <div class="map">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d12120.809245605833!2d49.6735533!3d40.581289549999994!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x403097a58506ef15%3A0x698ff01b1e2a5565!2sSumgait%20beach!5e0!3m2!1sen!2saz!4v1747627310183!5m2!1sen!2saz"
                            width="100%"
                            height="450"
                            style="border-radius:24px;"
                            allowfullscreen
                            loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade">
                        </iframe>
                    </div>

                </div>
                <div class="listing-tab">
                    <div class="listing-tab-header">
                        <h2 class="title">Listing</h2>
                        <div class="tab-buttons">
                            <button class="tab-btn active" data-filter="all">All</button>
                            <button class="tab-btn" data-filter="rent">For rent</button>
                            <button class="tab-btn" data-filter="sale">For sale</button>
                        </div>
                    </div>


                    <div class="listing-cards g-3" id="property-listing">
                        <?php $__currentLoopData = $properties->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageIndex => $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginal14063778454bc98f1538c2c8a2237ab4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14063778454bc98f1538c2c8a2237ab4 = $attributes; } ?>
<?php $component = App\View\Components\PropertyCard::resolve(['image' => $property['image'],'title' => $property['title'],'address' => $property['address'],'beds' => $property['beds'],'baths' => $property['baths'],'area' => $property['area'],'price' => $property['price']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('property-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PropertyCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'properti-card property-card','id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($property['id']),'data-status' => ''.e(strtolower(str_replace(' ', '', $property['extra']['status'] ?? 'all'))).'','data-page' => ''.e($pageIndex + 1).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14063778454bc98f1538c2c8a2237ab4)): ?>
<?php $attributes = $__attributesOriginal14063778454bc98f1538c2c8a2237ab4; ?>
<?php unset($__attributesOriginal14063778454bc98f1538c2c8a2237ab4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14063778454bc98f1538c2c8a2237ab4)): ?>
<?php $component = $__componentOriginal14063778454bc98f1538c2c8a2237ab4; ?>
<?php unset($__componentOriginal14063778454bc98f1538c2c8a2237ab4); ?>
<?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="pagination-agencies">
                        <nav aria-label="Page navigation">
                            <ul class="pagination mb-0">
                                <li class="page-item">
                                    <a class="page-link" href="#" aria-label="Previous">
                                        <i class="bi bi-chevron-left"></i>
                                    </a>
                                </li>
                                <li class="page-item"><a class="page-link" href="#">1</a></li>
                                <li class="page-item active" aria-current="page"><a class="page-link" href="#">2</a></li>
                                <li class="page-item disabled"><a class="page-link" href="#">...</a></li>
                                <li class="page-item"><a class="page-link" href="#">20</a></li>
                                <li class="page-item">
                                    <a class="page-link" href="#" aria-label="Next">
                                        <i class="bi bi-chevron-right"></i>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>


                </div>
            </section>
            <section class="side-right sticky">
                <div class="">
                    <?php if (isset($component)) { $__componentOriginal5c2bec5cc6712233e58dbf708ca99246 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2bec5cc6712233e58dbf708ca99246 = $attributes; } ?>
<?php $component = App\View\Components\ContactForm::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('contact-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ContactForm::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2bec5cc6712233e58dbf708ca99246)): ?>
<?php $attributes = $__attributesOriginal5c2bec5cc6712233e58dbf708ca99246; ?>
<?php unset($__attributesOriginal5c2bec5cc6712233e58dbf708ca99246); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2bec5cc6712233e58dbf708ca99246)): ?>
<?php $component = $__componentOriginal5c2bec5cc6712233e58dbf708ca99246; ?>
<?php unset($__componentOriginal5c2bec5cc6712233e58dbf708ca99246); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal6421e0b7a946b1902b5777844e4d5639 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6421e0b7a946b1902b5777844e4d5639 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feature--listings','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('feature--listings'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6421e0b7a946b1902b5777844e4d5639)): ?>
<?php $attributes = $__attributesOriginal6421e0b7a946b1902b5777844e4d5639; ?>
<?php unset($__attributesOriginal6421e0b7a946b1902b5777844e4d5639); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6421e0b7a946b1902b5777844e4d5639)): ?>
<?php $component = $__componentOriginal6421e0b7a946b1902b5777844e4d5639; ?>
<?php unset($__componentOriginal6421e0b7a946b1902b5777844e4d5639); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal273ce9cda454e3b87cfaf16916e545ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal273ce9cda454e3b87cfaf16916e545ea = $attributes; } ?>
<?php $component = App\View\Components\ConnectAgent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('connect-agent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ConnectAgent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal273ce9cda454e3b87cfaf16916e545ea)): ?>
<?php $attributes = $__attributesOriginal273ce9cda454e3b87cfaf16916e545ea; ?>
<?php unset($__attributesOriginal273ce9cda454e3b87cfaf16916e545ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal273ce9cda454e3b87cfaf16916e545ea)): ?>
<?php $component = $__componentOriginal273ce9cda454e3b87cfaf16916e545ea; ?>
<?php unset($__componentOriginal273ce9cda454e3b87cfaf16916e545ea); ?>
<?php endif; ?>
                </div>



            </section>
        </div>


    </div>

</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('webui::layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/metraj.az/Modules/WebUI/Resources/views/Pages/agency-detail.blade.php ENDPATH**/ ?>
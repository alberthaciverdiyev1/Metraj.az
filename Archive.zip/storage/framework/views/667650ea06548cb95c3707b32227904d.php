<?php $__empty_1 = true; $__currentLoopData = $js; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" crossorigin=""></script>
    <script src="<?php echo e(asset('webui/js/'.$j)); ?>"></script>
       <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>
<?php /**PATH /home/albert/Workspace/metraj.az/Modules/WebUI/Resources/views/partials/js.blade.php ENDPATH**/ ?>
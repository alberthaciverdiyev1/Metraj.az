<div class="amenities-and-features">
    <h3>Amenities And Features</h3>
    <div class="boxes-feature">
        <?php for($i = 0; $i < $columns; $i++): ?>
            <div class="box-feature">
                <ul>
                    <?php $__currentLoopData = array_slice($amenities, $i * ceil(count($amenities)/$columns), ceil(count($amenities)/$columns)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="feature-item">
                          
                            <?php echo e($item); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endfor; ?>
    </div>
</div><?php /**PATH /home/albert/Workspace/metraj.az/resources/views/components/amenities.blade.php ENDPATH**/ ?>
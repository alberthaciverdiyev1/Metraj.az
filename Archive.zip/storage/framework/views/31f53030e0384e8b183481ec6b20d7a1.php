<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<section id="navigation" class="py-3">
    <div class="container mx-auto px-4 flex items-center gap-2">
        <a href="<?php echo e(route('home')); ?>" class="text-[color:var(--primary)] font-bold flex items-center hover:text-black">
            Home
        </a>
        <span class="text-gray-400">›</span>
        <a href="<?php echo e(route('agencies')); ?>" class="text-gray-600">
            Agencies
        </a>
    </div>
</section>
<section id="settings-icon">
    <div class="container mx-auto px-4">
        <div class="settings-icon">
            <i class="bi bi-gear"></i>
        </div>
    </div>
</section>

<div class="gotop" id="scrollToTop">
    <svg class="progress-circle" width="45" height="45">
        <circle class="bg" cx="22.5" cy="22.5" r="18"></circle>
        <circle class="progress" cx="22.5" cy="22.5" r="18"></circle>
    </svg>
    <div class="up">
        <i class="bi bi-arrow-up-short"></i>
    </div>
</div>

<main>
    <div class="container  flex side mx-auto px-4">
        <section id="agencies">
            <div class="agencies-header">
                <div class="flex  flex-col lg:flex-row justify-between gap-4 mb-5">
                    <h2 class="text-2xl lg:text-4xl font-bold text-[color:var(--text-color)]">
                        Agencies
                    </h2>

                    <div class="flex flex-wrap items-center gap-2">
                        <button id="gridViewBtn" class="view-toggle active px-3 py-2 hover:bg-[color:var(--primary)] hover:text-white transition rounded-md border border-[var(--border-color)]">
                            <i class="bi bi-grid-3x3-gap"></i>
                        </button>

                        <button id="listViewBtn" class="view-toggle px-3 py-2 rounded-md border hover:bg-[color:var(--primary)] hover:text-white transition border-[var(--border-color)]">
                            <i class="fas fa-list text-[color:var(--icon-grey)]"></i>
                        </button>




                        <div class="relative">
                            <button class="flex items-center border border-[var(--border-color)] px-4 py-2 rounded-md">
                                Oldest <i class="fas fa-chevron-down ml-2"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="agencies-cards">
                <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="agencies-card">
                    <figure>
                        <img class="image-agency" src="<?php echo e($agency['image']); ?>" alt="House Image">
                    </figure>
                    <div class="logo">
                        <img src="<?php echo e($agency['logo']); ?>" alt="Logo">
                    </div>
                    <div class="text">
                        <div class="header"><?php echo e($agency['name']); ?></div>
                        <p><?php echo e($agency['address']); ?></p>

                        <div class="desc"><?php echo e(\Illuminate\Support\Str::limit($agency['about'], 150)); ?></div>
                        <div class="info"><span>Listing:</span> <?php echo e($agency['listing_count']); ?></div>
                        <div class="info"><span>Hotline:</span> <?php echo e($agency['hotline']); ?></div>
                        <div class="info"><span>Phone:</span> <?php echo e($agency['phone']); ?></div>
                        <div class="info"><span>Email:</span> <?php echo e($agency['email']); ?></div>

                        <div class="footer">
                            <div class="icons">
                                <i class="bi bi-telephone-fill"></i>
                                <i class="bi bi-envelope-fill"></i>
                                <i class="bi bi-globe2"></i>
                            </div>
                            <div class="details-button">
                                <a href="<?php echo e(route('agency.details', $id)); ?>" class="relative inline-block px-6 py-3 rounded-xl border border-[color:var(--primary)] text-sm text-[color:var(--primary)] overflow-hidden transition-all duration-300 hover-effect-button">
                                    <span class="absolute inset-0 w-0 h-full bg-[color:var(--primary)] transition-all duration-300 ease-in-out z-0 hover-effect-button-fill"></span>
                                    <span class="relative z-10">Details</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="pagination-agencies">
                <nav aria-label="Page navigation">
                    <ul class="pagination mb-0">
                        <li class="page-item">
                            <a class="page-link" href="#" aria-label="Previous">
                                <i class="bi bi-chevron-left"></i>
                            </a>
                        </li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item active" aria-current="page"><a class="page-link" href="#">2</a></li>
                        <li class="page-item disabled"><a class="page-link" href="#">...</a></li>
                        <li class="page-item"><a class="page-link" href="#">20</a></li>
                        <li class="page-item">
                            <a class="page-link" href="#" aria-label="Next">
                                <i class="bi bi-chevron-right"></i>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </section>
        <section id="contact">
            <?php if (isset($component)) { $__componentOriginal5c2bec5cc6712233e58dbf708ca99246 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c2bec5cc6712233e58dbf708ca99246 = $attributes; } ?>
<?php $component = App\View\Components\ContactForm::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('contact-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ContactForm::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c2bec5cc6712233e58dbf708ca99246)): ?>
<?php $attributes = $__attributesOriginal5c2bec5cc6712233e58dbf708ca99246; ?>
<?php unset($__attributesOriginal5c2bec5cc6712233e58dbf708ca99246); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c2bec5cc6712233e58dbf708ca99246)): ?>
<?php $component = $__componentOriginal5c2bec5cc6712233e58dbf708ca99246; ?>
<?php unset($__componentOriginal5c2bec5cc6712233e58dbf708ca99246); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal6421e0b7a946b1902b5777844e4d5639 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6421e0b7a946b1902b5777844e4d5639 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.feature--listings','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('feature--listings'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6421e0b7a946b1902b5777844e4d5639)): ?>
<?php $attributes = $__attributesOriginal6421e0b7a946b1902b5777844e4d5639; ?>
<?php unset($__attributesOriginal6421e0b7a946b1902b5777844e4d5639); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6421e0b7a946b1902b5777844e4d5639)): ?>
<?php $component = $__componentOriginal6421e0b7a946b1902b5777844e4d5639; ?>
<?php unset($__componentOriginal6421e0b7a946b1902b5777844e4d5639); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal273ce9cda454e3b87cfaf16916e545ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal273ce9cda454e3b87cfaf16916e545ea = $attributes; } ?>
<?php $component = App\View\Components\ConnectAgent::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('connect-agent'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ConnectAgent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal273ce9cda454e3b87cfaf16916e545ea)): ?>
<?php $attributes = $__attributesOriginal273ce9cda454e3b87cfaf16916e545ea; ?>
<?php unset($__attributesOriginal273ce9cda454e3b87cfaf16916e545ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal273ce9cda454e3b87cfaf16916e545ea)): ?>
<?php $component = $__componentOriginal273ce9cda454e3b87cfaf16916e545ea; ?>
<?php unset($__componentOriginal273ce9cda454e3b87cfaf16916e545ea); ?>
<?php endif; ?>
            




        </section>
    </div>




    </div>

</main>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('webui::layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/metraj.az/Modules/WebUI/Resources/views/home/agencies.blade.php ENDPATH**/ ?>
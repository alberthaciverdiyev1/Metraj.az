<section id="settings-icon">
    <div class="container mx-auto px-4">
        <div class="settings-icon">
            <i class="bi bi-gear"></i>
        </div>
    </div>
</section>
<?php /**PATH /home/albert/Workspace/metraj.az/resources/views/components/settings-icon.blade.php ENDPATH**/ ?>
<div class="title-section">
    <h2><?php echo e($title); ?></h2>
    <p><?php echo e($subtitle); ?></p>
</div>
<?php /**PATH /home/albert/Workspace/metraj.az/resources/views/components/title.blade.php ENDPATH**/ ?>
<section id="property-detail">
    <h3>Property Details</h3>
    <p class="units">
        <?php echo e($details['units'] ?? ''); ?> <?php echo e($details['unit_mix'] ?? ''); ?>. 
        The building is a total of <?php echo e($details['building_size'] ?? ''); ?> and situated on a <?php echo e($details['lot_size'] ?? ''); ?> lot. 
        <?php echo e($details['access'] ?? ''); ?> The building is <?php echo e($details['metering'] ?? ''); ?>.
    </p>
    <div class="read-more">Read more
        <i class="bi bi-arrow-down-circle"></i>
    </div>
    <div class="box">
        <ul>
            <li class="flex">
                <p class="fw-6">ID</p>
                <p><?php echo e($extra['id']); ?></p>
            </li>
            <li class="flex">
                <p class="fw-6">Price</p>
                <p><?php echo e($extra['price_text']); ?></p>
            </li>
            <li class="flex">
                <p class="fw-6">Size</p>
                <p><?php echo e($extra['size']); ?></p>
            </li>
            <li class="flex">
                <p class="fw-6">Rooms</p>
                <p><?php echo e($extra['rooms']); ?></p>
            </li>
            <li class="flex">
                <p class="fw-6">Baths</p>
                <p><?php echo e($extra['baths'] ?? 'N/A'); ?></p>
            </li>
        </ul>
        <ul>
            <li class="flex">
                <p class="fw-6">Beds</p>
                <p><?php echo e($extra['beds_exact']); ?></p>
            </li>
            <li class="flex">
                <p class="fw-6">Year built</p>
                <p><?php echo e($extra['year_built']); ?></p>
            </li>
            <li class="flex">
                <p class="fw-6">Type</p>
                <p><?php echo e($extra['type']); ?></p>
            </li>
            <li class="flex">
                <p class="fw-6">Status</p>
                <p><?php echo e($extra['status']); ?></p>
            </li>
            <li class="flex">
                <p class="fw-6">Garage</p>
                <p><?php echo e($extra['garage']); ?></p>
            </li>
        </ul>
    </div>
</section><?php /**PATH /home/albert/Workspace/metraj.az/resources/views/components/property-details.blade.php ENDPATH**/ ?>
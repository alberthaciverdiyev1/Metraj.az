<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<main>
    <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
    ['label' => 'Home', 'url' => route('home')],
    ['label' => 'Property Listing', 'url' => route('listing')],
])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginaldfa1f9284bad1280f1688ddb5372b4e0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldfa1f9284bad1280f1688ddb5372b4e0 = $attributes; } ?>
<?php $component = App\View\Components\SettingsIcon::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('settings-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SettingsIcon::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldfa1f9284bad1280f1688ddb5372b4e0)): ?>
<?php $attributes = $__attributesOriginaldfa1f9284bad1280f1688ddb5372b4e0; ?>
<?php unset($__attributesOriginaldfa1f9284bad1280f1688ddb5372b4e0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldfa1f9284bad1280f1688ddb5372b4e0)): ?>
<?php $component = $__componentOriginaldfa1f9284bad1280f1688ddb5372b4e0; ?>
<?php unset($__componentOriginaldfa1f9284bad1280f1688ddb5372b4e0); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalb7adccc229b3a14ffb5f56d70b867112 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb7adccc229b3a14ffb5f56d70b867112 = $attributes; } ?>
<?php $component = App\View\Components\ScrollToTop::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('scroll-to-top'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ScrollToTop::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb7adccc229b3a14ffb5f56d70b867112)): ?>
<?php $attributes = $__attributesOriginalb7adccc229b3a14ffb5f56d70b867112; ?>
<?php unset($__attributesOriginalb7adccc229b3a14ffb5f56d70b867112); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb7adccc229b3a14ffb5f56d70b867112)): ?>
<?php $component = $__componentOriginalb7adccc229b3a14ffb5f56d70b867112; ?>
<?php unset($__componentOriginalb7adccc229b3a14ffb5f56d70b867112); ?>
<?php endif; ?>
    <section class="property-listing py-4">
        <div class="container mx-auto px-4">
            <div class="flex  flex-col lg:flex-row justify-between gap-4 mb-5">
                <h2 class="text-2xl lg:text-4xl font-bold text-[color:var(--text-color)]">
                    Property listing
                </h2>

                <div class="flex flex-wrap items-center gap-2">

                    <?php echo $__env->make('webui::components.filter-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <button id="gridViewBtn" class="px-3 grid-btn py-2 rounded-md active-filter" data-view="grid">
                        <i class="bi bi-grid-3x3-gap"></i>
                    </button>

                    <button id="listViewBtn" class=" px-3 py-2 list border border-[var(--border-color)] rounded-md" data-view="list">
                        <i class="fas fa-list text-[color:var(--icon-grey)] "></i>
                    </button>





                    <div class="relative">
                        <button class="flex items-center border border-[var(--border-color)] px-4 py-2 rounded-md">
                            Sort by (Default) <i class="fas fa-chevron-down ml-2"></i>
                        </button>
                    </div>
                </div>
            </div>

            <div id="propertyContainer" class="pt-8 grid grid-cols-1 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-7">


                <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (isset($component)) { $__componentOriginal14063778454bc98f1538c2c8a2237ab4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14063778454bc98f1538c2c8a2237ab4 = $attributes; } ?>
<?php $component = App\View\Components\PropertyCard::resolve(['image' => $property['image'],'title' => $property['title'],'address' => $property['address'],'beds' => $property['beds'],'baths' => $property['baths'],'area' => $property['area'],'price' => $property['price']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('property-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\PropertyCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($property['id'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14063778454bc98f1538c2c8a2237ab4)): ?>
<?php $attributes = $__attributesOriginal14063778454bc98f1538c2c8a2237ab4; ?>
<?php unset($__attributesOriginal14063778454bc98f1538c2c8a2237ab4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14063778454bc98f1538c2c8a2237ab4)): ?>
<?php $component = $__componentOriginal14063778454bc98f1538c2c8a2237ab4; ?>
<?php unset($__componentOriginal14063778454bc98f1538c2c8a2237ab4); ?>
<?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>


        </div>
        <div class="result">
            <div class="text">
                Showing 1-9 of 12 results.
            </div>
            <nav aria-label="Page navigation">
                <ul class="pagination mb-0">
                    <li class="page-item">
                        <a class="page-link" href="#" aria-label="Previous">
                            <i class="bi bi-chevron-left"></i>
                        </a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                    <li class="page-item active" aria-current="page"><a class="page-link" href="#">2</a></li>
                    <li class="page-item disabled"><a class="page-link" href="#">...</a></li>
                    <li class="page-item"><a class="page-link" href="#">20</a></li>
                    <li class="page-item">
                        <a class="page-link" href="#" aria-label="Next">
                            <i class="bi bi-chevron-right"></i>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('webui::layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/metraj.az/Modules/WebUI/Resources/views/Pages/listing.blade.php ENDPATH**/ ?>
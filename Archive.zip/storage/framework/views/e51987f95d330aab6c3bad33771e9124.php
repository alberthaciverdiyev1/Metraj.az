<!doctype html>

<html lang="en">
    <?php echo $__env->make('webui::partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <body>
        <?php echo $__env->make('webui::partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>
        
        <?php echo $__env->make('webui::partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo $__env->make('webui::partials.js', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </body>
</html>
<?php /**PATH /home/albert/Workspace/metraj.az/Modules/WebUI/Resources/views/layout.blade.php ENDPATH**/ ?>
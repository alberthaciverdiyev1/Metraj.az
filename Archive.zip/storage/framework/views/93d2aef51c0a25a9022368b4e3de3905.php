<?php $__env->startSection('title', 'FAQs'); ?>


<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginaldfa1f9284bad1280f1688ddb5372b4e0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldfa1f9284bad1280f1688ddb5372b4e0 = $attributes; } ?>
<?php $component = App\View\Components\SettingsIcon::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('settings-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SettingsIcon::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldfa1f9284bad1280f1688ddb5372b4e0)): ?>
<?php $attributes = $__attributesOriginaldfa1f9284bad1280f1688ddb5372b4e0; ?>
<?php unset($__attributesOriginaldfa1f9284bad1280f1688ddb5372b4e0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldfa1f9284bad1280f1688ddb5372b4e0)): ?>
<?php $component = $__componentOriginaldfa1f9284bad1280f1688ddb5372b4e0; ?>
<?php unset($__componentOriginaldfa1f9284bad1280f1688ddb5372b4e0); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginalb7adccc229b3a14ffb5f56d70b867112 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb7adccc229b3a14ffb5f56d70b867112 = $attributes; } ?>
<?php $component = App\View\Components\ScrollToTop::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('scroll-to-top'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ScrollToTop::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb7adccc229b3a14ffb5f56d70b867112)): ?>
<?php $attributes = $__attributesOriginalb7adccc229b3a14ffb5f56d70b867112; ?>
<?php unset($__attributesOriginalb7adccc229b3a14ffb5f56d70b867112); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb7adccc229b3a14ffb5f56d70b867112)): ?>
<?php $component = $__componentOriginalb7adccc229b3a14ffb5f56d70b867112; ?>
<?php unset($__componentOriginalb7adccc229b3a14ffb5f56d70b867112); ?>
<?php endif; ?>
<?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
    ['label' => 'Home', 'url' => route('home')],
    ['label' => 'Blog', 'url' => route('blog')],
])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<header>
    <div class="container mx-auto px-4">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-start gap-4 md:gap-6">
            <h2 class="text-2xl lg:text-4xl font-bold py-4 text-[color:var(--text-color)]">
                Blog grid
            </h2>

            <div class="flex flex-wrap items-center gap-2">


                <button id="gridViewBtn" class="px-3 grid-btn py-2 rounded-md active-filter" data-view="grid">
                    <i class="bi bi-grid-3x3-gap"></i>
                </button>

                <button id="listViewBtn" class=" px-3 py-2 list border border-[var(--border-color)] rounded-md" data-view="list">
                    <i class="fas fa-list text-[color:var(--icon-grey)] "></i>
                </button>





            </div>
        </div>
    </div>
</header>
<main>
    <section id="blog-cards">
        <div class="container mx-auto px-3">
            <div class="blog-cards">
                <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="blog-card">
                    <div class="blog-card-image">
                        <img src="<?php echo e($post['images'][0]); ?>" alt="blog-card-image">
                        <span><?php echo e($post['category']); ?></span>
                    </div>
                    <div class="blog-card-info">
                        <div class="blog-time">
                            <i class="bi bi-clock-history"></i>
                            <p><?php echo e($post['date']); ?></p>
                        </div>
                        <div class="blog-title">
                            <h3><?php echo e(Str::limit($post['title'], 50)); ?></h3>
                        </div>

                        <a href="<?php echo e(route('blog.details', ['id' => $id])); ?>" class="blog-button">
                            Read More <i class="bi bi-arrow-right-circle"></i>
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>

    </section>
    <div class="pagination-blog mx-auto">
        <nav aria-label="Page navigation" class="w-[20%] mx-auto py-3">
            <ul class="pagination mb-0">
                <li class="page-item">
                    <a class="page-link" href="#" aria-label="Previous">
                        <i class="bi bi-chevron-left"></i>
                    </a>
                </li>
                <li class="page-item"><a class="page-link" href="#">1</a></li>
                <li class="page-item active" aria-current="page"><a class="page-link" href="#">2</a></li>
                <li class="page-item disabled"><a class="page-link" href="#">...</a></li>
                <li class="page-item"><a class="page-link" href="#">20</a></li>
                <li class="page-item">
                    <a class="page-link" href="#" aria-label="Next">
                        <i class="bi bi-chevron-right"></i>
                    </a>
                </li>
            </ul>
        </nav>
    </div>


</main>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('webui::layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/albert/Workspace/metraj.az/Modules/WebUI/Resources/views/Pages/blog.blade.php ENDPATH**/ ?>
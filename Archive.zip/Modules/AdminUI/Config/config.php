<?php

return [
    'name' => 'AdminUI',
    'icon' => 'AdminUI',
];

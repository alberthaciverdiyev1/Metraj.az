<?php

namespace Modules\$STUDLY_NAME$\Entities;

use Illuminate\Database\Eloquent\Model;

class $CLASS$ extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = '';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [

    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [

    ];
}

<?php

namespace Modules\Seo\Database\Seeders;

use Illuminate\Database\Seeder;

class SeoDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}

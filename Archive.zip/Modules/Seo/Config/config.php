<?php

return [
    'name' => 'Seo',
    'icon' => 'Seo',
];

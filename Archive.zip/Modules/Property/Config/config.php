<?php

return [
    'name' => 'Property',
    'icon' => 'Property',
];

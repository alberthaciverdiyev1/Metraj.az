<?php

namespace Modules\Indicator\Database\Seeders;

use Illuminate\Database\Seeder;

class IndicatorDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}

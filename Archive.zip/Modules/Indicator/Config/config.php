<?php

return [
    'name' => 'Indicator',
    'icon' => 'Indicator',
];

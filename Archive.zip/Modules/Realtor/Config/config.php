<?php

return [
    'name' => 'Realtor',
    'icon' => 'Realtor',
];

<?php

namespace Modules\Realtor\Database\Seeders;

use Illuminate\Database\Seeder;

class RealtorDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}

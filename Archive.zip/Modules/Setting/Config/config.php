<?php

return [
    'name' => 'Setting',
    'icon' => 'Setting',
];

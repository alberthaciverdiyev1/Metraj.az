<?php

return [
    'name' => 'Town',
    'icon' => 'Town',
];

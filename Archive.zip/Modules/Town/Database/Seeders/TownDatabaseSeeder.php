<?php

namespace Modules\Town\Database\Seeders;

use Illuminate\Database\Seeder;

class TownDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}

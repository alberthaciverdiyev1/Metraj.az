<?php

return [
    'name' => 'City',
    'icon' => 'City',
];

<?php

return [
    'name' => 'webui',
    'icon' => 'WebUI',
    
];

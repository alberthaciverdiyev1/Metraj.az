<div style="text-align: center; padding: 100px;">
    <h1 style="color:var(--text-color)">Oh no... We lost this page</h1>
    <p>We searched everywhere but couldn’t find what you’re looking for. Let’s find
        a better place for you to go.</p>
    <a class="" href="{{ route('home') }}" >Back To Home</a>
</div>

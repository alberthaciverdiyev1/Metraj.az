<?php

namespace Modules\Feature\Database\Seeders;

use Illuminate\Database\Seeder;

class FeatureDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}

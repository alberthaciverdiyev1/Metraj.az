<?php

return [
    'name' => 'Feature',
    'icon' => 'Feature',
];

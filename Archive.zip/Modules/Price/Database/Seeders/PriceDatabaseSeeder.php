<?php

namespace Modules\Price\Database\Seeders;

use Illuminate\Database\Seeder;

class PriceDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}

<?php

return [
    'name' => 'Price',
    'icon' => 'Price',
];

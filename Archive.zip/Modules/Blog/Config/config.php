<?php

return [
    'name' => 'Blog',
    'icon' => 'Blog',
];

<?php

return [
    'name' => 'Base',
    'icon' => 'Base',
];

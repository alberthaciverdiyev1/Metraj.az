<?php

return [
    'name' => 'User',
    'icon' => 'User',
];

<?php

return [
    'name' => 'Media',
    'icon' => 'Media',
];

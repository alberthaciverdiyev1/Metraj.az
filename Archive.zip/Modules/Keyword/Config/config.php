<?php

return [
    'name' => 'Keyword',
    'icon' => 'Keyword',
];

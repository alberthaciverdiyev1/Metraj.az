<?php

namespace Modules\Keyword\Database\Seeders;

use Illuminate\Database\Seeder;

class KeywordDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}

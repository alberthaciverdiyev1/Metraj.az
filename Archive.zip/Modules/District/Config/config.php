<?php

return [
    'name' => 'District',
    'icon' => 'District',
];
